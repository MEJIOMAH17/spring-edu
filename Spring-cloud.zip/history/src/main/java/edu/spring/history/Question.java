package edu.spring.history;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.util.List;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class Question {

    @GeneratedValue
    @Id
    private Long id;
    @Column
    private String question;
    @Column
    private String answer;


    public Question(String question, String answer) {
        this.question = question;
        this.answer = answer;

    }
}

