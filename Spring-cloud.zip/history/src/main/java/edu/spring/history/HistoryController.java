package edu.spring.history;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.PostConstruct;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@RestController
public class HistoryController {
    @Autowired
    QuestionRepository repository;


    @PostConstruct
    public void init() throws IOException {
        JsonNode jsonNode = new ObjectMapper().readTree(new FileReader("/Users/mark/history/src/main/resources/dump.json"));
        JsonNode results = jsonNode.get("results");
        for (JsonNode result : results) {
            JsonNode qustion = result.get("question");
            JsonNode answer = result.get("correct_answer");
            Question question = new Question(qustion.textValue(), answer.textValue());
            repository.save(question);
        }

    }

    @RequestMapping("/questions/{number}")
    public Iterable<Question> questions(@PathVariable int number) {
        List<Question> all = repository.findAll();
        Collections.shuffle(all);
        return all.stream().limit(number).collect(Collectors.toList());
    }

    @RequestMapping("/question/add")
    public Question questions(@RequestParam String question, @RequestParam String answer) {
        return repository.save(new Question(question, answer));
    }

    @RequestMapping("/question/delete")
    public void questions(@RequestParam long id) {
        repository.deleteById(id);
    }
}
