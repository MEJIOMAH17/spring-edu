package edu.spring.examinator;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class ExaminatorController {

    private Map<String, String> themeToUrl = new HashMap<>();
    private RestTemplate restTemplate = new RestTemplate();

    public ExaminatorController() {
        themeToUrl.put("math", "http://localhost:8080/questions/");
        themeToUrl.put("history", "http://localhost:9090/questions/");
    }


    @RequestMapping("/examinator")
    public Iterable<Question> getQuestions(@RequestBody Iterable<Rq> request) {
        List<Question> result = new ArrayList<>();
        for (Rq rq : request) {
            String url = themeToUrl.get(rq.getTheme());
            ResponseEntity<List<Question>> qustions = restTemplate.exchange(url + rq.getNumber(),
                    HttpMethod.GET,
                    null,
                    new ParameterizedTypeReference<List<Question>>() {
                    });
            result.addAll(qustions.getBody());
        }
        return result;

    }

    @RequestMapping("/test")
    public Iterable<Rq> test() {
        ArrayList<Rq> rqs = new ArrayList<>();
        rqs.add(new Rq("math", 4));
        rqs.add(new Rq("history", 4));
        return rqs;
    }

}
