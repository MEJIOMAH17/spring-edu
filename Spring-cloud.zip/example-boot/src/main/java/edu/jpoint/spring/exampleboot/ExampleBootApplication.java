package edu.jpoint.spring.exampleboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@SpringBootApplication
public class ExampleBootApplication {

    public static void main(String[] args) {
        SpringApplication.run(ExampleBootApplication.class, args);
    }

    @Bean
    public ExecutorService threadPoolExecutor() {
        return  Executors.newFixedThreadPool(4);
    }
}
