package edu.jpoint.spring.exampleboot;

import edu.jpoint.spring.springedu.annotation.Benchmark;
import edu.jpoint.spring.springedu.annotation.NotifyAboutException;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.HtmlEmail;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import java.util.Collections;
import java.util.Date;

@Component
public class TestComponent {
    @Autowired
    TestComponent self;

    @EventListener(ContextRefreshedEvent.class)
    public void test() throws EmailException, AddressException {
//        self.legacyShit();
//        self.concat("hello ", "world");
        try {
        self.exampleException();
        } catch (Exception e) {
            //ignored
        }

    }

    @Deprecated
    public void legacyShit() {
        System.out.println("hello from depricated");
    }

    @Benchmark
    public String concat(String one, String two) {
        return one + two;
    }

    @NotifyAboutException
    public void exampleException() {
        self.exampleException2();
    }

    @NotifyAboutException
    public void exampleException2() {
        throw new RuntimeException(new Date().toString());
    }
}
