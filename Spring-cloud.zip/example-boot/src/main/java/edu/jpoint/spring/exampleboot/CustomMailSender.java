package edu.jpoint.spring.exampleboot;

import edu.jpoint.spring.springedu.aspect.MailSender;
import org.springframework.stereotype.Component;

@Component
public class CustomMailSender extends MailSender {

    @Override
    public void send() {
        System.out.println("CustomSend");
    }
}
