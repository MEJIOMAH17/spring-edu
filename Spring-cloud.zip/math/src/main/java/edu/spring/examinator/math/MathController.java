package edu.spring.examinator.math;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@RestController
public class MathController {
    @RequestMapping("/questions/{number}")
    public List<Question> questions(@PathVariable int number, @RequestParam(defaultValue = "100") Integer diapason) {
        List<Question> questions = new ArrayList<>(number);
        Random random = new Random();
        for (int i = 0; i < number; i++) {
            int a = random.nextInt(diapason);
            int b = random.nextInt(diapason);
            questions.add(new Question(String.format("%s+%s=???", a, b), String.valueOf(a + b)));
        }
        return questions;
    }
}
