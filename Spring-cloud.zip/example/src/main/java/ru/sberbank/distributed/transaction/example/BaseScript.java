package ru.sberbank.distributed.transaction.example;

import org.springframework.beans.factory.annotation.Autowired;
import ru.sberbank.distributed.transaction.AbstractScript;
import ru.sberbank.distributed.transaction.example.cdmstub.CdmMock;
import ru.sberbank.distributed.transaction.example.cdmstub.Service;
import ru.sberbank.distributed.transaction.example.rollback.ContinueProcess;
import ru.sberbank.distributed.transaction.example.rollback.RollbackProcess;

import javax.annotation.PostConstruct;

public abstract class BaseScript extends AbstractScript<Integer> {
    private String serviceId;
    @Autowired
    private CdmMock mock;
    @Autowired
    private RollbackProcess rollbackProcess;
    @Autowired
    private ContinueProcess continueProcess;


    public Integer run() throws Exception {
        //логирование, время и всякая чепуха до бизнес кода
        Integer result = innerRun();
        //логирование время и всякая чепуха после бизнес кода
        return result;
    }

    protected void registerResponse() {
        Service service = mock.getService(serviceId);
        service.setStatus(Service.Status.PERFORMED);
    }

    protected abstract Integer innerRun() throws Exception;


    public BaseScript() {

    }

    public String getServiceId() {
        return serviceId;
    }

    public void setServiceId(String serviceId) {
        this.serviceId = serviceId;
    }

    public void createService(String serviceId) {
        Service service = mock.getService(serviceId);
        service.setScriptClass(this.getClass());
        setServiceId(serviceId);
    }

    public CdmMock getMock() {
        return mock;
    }
}
