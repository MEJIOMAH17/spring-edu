package ru.sberbank.distributed.transaction.example;

import lombok.AllArgsConstructor;
import lombok.experimental.Delegate;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.io.StringReader;
import java.io.StringWriter;

public class XMLCreator {
    public static void main(String[] args) {
        System.out.println(createDocument());

    }

    private static String createDocument() {

        try {
            DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
            Doc document = new Doc(documentBuilder.newDocument());

            //<editor-fold desc="Header">
            Element header = document.createElement("header");
            header.appendChild(document.createDataElement("Отправитель:",
                    "MS EREMENKO OLGA 18 IPOH LANE +16 02 EMERY POINT SINGAPORE 438622;"));
            header.appendChild(document.createDataElement("Получатель:",
                    "ЕРЕМЕНКО ОЛЬГА МИХАЙЛОВНА; 690000, РОССИЯ, КРАЙ ПРИМОРСКИЙ," +
                            " Г ВЛАДИВОСТОК, ПР-КТ ОСТРЯКОВА, д 57, кв 9;"));
            header.appendChild(document.createDataElement("Счет отправителя:", ""));
            header.appendChild(document.createDataElement("Счет получателя:", ""));
            header.appendChild(document.createDataElement("Банк отправителя:", "СБЕРБАНК РОССИИ ОАО"));
            header.appendChild(document.createDataElement("Банк получателя:", "СБЕРБАНК РОССИИ ОАО"));
            header.appendChild(document.createDataElement("БИК банка отправителя:", ""));
            header.appendChild(document.createDataElement("БИК банка получателя:", ""));
            header.appendChild(document.createDataElement("Сумма в валюте счета:", "972500.00"));
            header.appendChild(document.createDataElement("Наименование валюты счета:",
                    "Российский рубль"));
            header.appendChild(document.createDataElement("Сумма операции в валюте перевода:", "25000.00"));
            header.appendChild(document.createDataElement("Наименование валюты перевода:",
                    "Сингапурский доллар"));
            //</editor-fold>
            //<editor-fold desc="Body">
            Element body = document.createElement("body");
            body.appendChild(document.createDataElement("Наименование операции:",
                    "Перевод в иностранной валюте для зачисления на счет резидента (F02-1)"));
            body.appendChild(document.createDataElement("Описание проводки:",
                    "Прямые межвкладные проводки"));
            body.appendChild(document.createDataElement("Назначение платежа:", "ROITING 8635-0168"));
            //</editor-fold>


            Element parsedOperationDataInner = document.createElement("parsedOperationData");
            parsedOperationDataInner.setAttribute("xmlns", "http://ccontrol.iteco.ru/ParsedOperationData");
            parsedOperationDataInner.appendChild(header);
            parsedOperationDataInner.appendChild(body);

            Element parsedOperationData = document.createElement("parsedOperationData");
            document.appendChild(parsedOperationData);
            parsedOperationData.appendChild(parsedOperationDataInner);

            return document.toString();

        } catch (ParserConfigurationException e) {
            throw new RuntimeException(e);
        }
    }

    @AllArgsConstructor
    public static class Doc implements Document {
        @Delegate
        private Document document;

        @Override
        public String toString() {
            DOMSource source = new DOMSource(document);
            try {
                StringWriter stringWriter = new StringWriter();
                StreamResult result = new StreamResult(stringWriter);

                TransformerFactory transformerFactory = TransformerFactory.newInstance();
                Transformer transformer = transformerFactory.newTransformer();
                transformer.transform(source, result);
                return stringWriter.toString();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }

        }

        public Element createDataElement(String fieldName, String value) {
            Element field = document.createElement("field");
            field.setTextContent(fieldName);
            Element valueEl = document.createElement("value");
            valueEl.setTextContent(value);
            Element dataElement = document.createElement("dataElement");
            dataElement.appendChild(field);
            dataElement.appendChild(valueEl);
            return dataElement;
        }
    }

}
