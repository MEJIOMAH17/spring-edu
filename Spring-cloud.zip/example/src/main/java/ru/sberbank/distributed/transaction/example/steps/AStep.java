package ru.sberbank.distributed.transaction.example.steps;

import org.springframework.beans.factory.annotation.Autowired;
import ru.sberbank.distributed.transaction.annotation.FullRollback;
import ru.sberbank.distributed.transaction.annotation.ParticalRollback;
import ru.sberbank.distributed.transaction.annotation.Regular;
import ru.sberbank.distributed.transaction.annotation.Step;

import java.util.Calendar;
import java.util.Map;

@Step
public class AStep extends ExampleStep<AStep> {
    @Autowired
    BStep bStep;

    @Regular
    public Calendar regular(int reg) {
        System.out.println("execution!!!");
        System.out.println("go  ae!!!");
        System.out.println("go  cdm!!!");


        getRollbacker().rollback(reg, 3L);

        return Calendar.getInstance();
    }


    @FullRollback
    public void rollback(int rollback, long id) {
        System.out.println("Происходит откат " + rollback);

        System.out.println("rollback cdm " + rollback);
        System.out.println("rollback ae " + rollback);
    }

    @ParticalRollback
    public void partical(int reg) {
        System.out.println("Частичный откат" + reg);
    }

    public static class SuperComplexityObject {
        int balance;
        String xxx;

    }
}
