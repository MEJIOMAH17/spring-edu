package ru.sberbank.distributed.transaction.example.steps;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import ru.sberbank.distributed.transaction.annotation.FullRollback;
import ru.sberbank.distributed.transaction.annotation.Regular;
import ru.sberbank.distributed.transaction.annotation.Step;

@Step
public class DStep extends ExampleStep<DStep> {
    @Regular
    public String regular(int reg) {
        getRollbacker().rollback(reg * reg);
        return "hello from d";
    }

    @FullRollback
    public void rollback(int rollback) {
        System.out.println("Происходит откат " + rollback);
    }
}
