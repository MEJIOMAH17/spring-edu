package ru.sberbank.distributed.transaction.example.rollback;

import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;
import ru.sberbank.distributed.transaction.AbstractContinueProcess;
import ru.sberbank.distributed.transaction.example.BaseScript;
import ru.sberbank.distributed.transaction.example.cdmstub.CdmMock;
import ru.sberbank.distributed.transaction.example.cdmstub.Operation;
import ru.sberbank.distributed.transaction.example.cdmstub.Service;

@Component
public class ContinueProcess extends AbstractContinueProcess {

    private CdmMock cdm;

    public ContinueProcess(CdmMock cdm) {
        this.cdm = cdm;
    }

    public void run(String serviceId) {
        Service service = cdm.getService(serviceId);
        Class<? extends BaseScript> scriptClass = service.getScriptClass();
        super.run(scriptClass, (clazz, id) -> {
            for (Operation operation : service.operations()) {
                if (operation.getStepClassAsString().equals(clazz)
                        && operation.getStepId() == id
                        && operation.getExecutionResult() != null) {
                    return operation.getExecutionResult();
                }
            }
            return null;
        });

    }
}
