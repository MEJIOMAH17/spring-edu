package ru.sberbank.distributed.transaction.example;

import java.io.*;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Solution {

    // Complete the climbingLeaderboard function below.
    static int[] climbingLeaderboard(int[] scores, int[] alice) {
        int[] result=new int[alice.length];
        int lastIndexInScore=scores.length-1;
        int positionFromEnd=0;
        int tmp=Integer.MIN_VALUE;
        for (int i = 0; i < alice.length; i++) {
            int currentResult=alice[i];
            boolean found_result=false;
            for (int j = lastIndexInScore; j >=0 ; j--) {
                int score=scores[j];
                if(tmp==score){
                    continue;
                }
                tmp=score;
                positionFromEnd++;
                if(currentResult<=score){
                    result[i]=positionFromEnd;
                    lastIndexInScore=j-1;
                    found_result=true;
                    break;
                }

            }
            if(!found_result){
                result[i]=Integer.MIN_VALUE;
            }
        }

        for (int i = 0; i < result.length; i++) {
            if(result[i]==Integer.MIN_VALUE){
                result[i]=1;
                continue;
            }
            result[i]=positionFromEnd-result[i]+1;
        }

        return result;
    }

    private static  Scanner scanner;

    static {
        try {
            scanner = new Scanner(new File("input.txt"));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) throws IOException {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter("output.txt"));

        int scoresCount = scanner.nextInt();
        scanner.skip("(\r\n|[\n\r\u2028\u2029\u0085])?");

        int[] scores = new int[scoresCount];

        String[] scoresItems = scanner.nextLine().split(" ");
        scanner.skip("(\r\n|[\n\r\u2028\u2029\u0085])?");

        for (int i = 0; i < scoresCount; i++) {
            int scoresItem = Integer.parseInt(scoresItems[i]);
            scores[i] = scoresItem;
        }

        int aliceCount = scanner.nextInt();
        scanner.skip("(\r\n|[\n\r\u2028\u2029\u0085])?");

        int[] alice = new int[aliceCount];

        String[] aliceItems = scanner.nextLine().split(" ");
        scanner.skip("(\r\n|[\n\r\u2028\u2029\u0085])?");

        for (int i = 0; i < aliceCount; i++) {
            int aliceItem = Integer.parseInt(aliceItems[i]);
            alice[i] = aliceItem;
        }

        int[] result = climbingLeaderboard(scores, alice);

        for (int i = 0; i < result.length; i++) {
            bufferedWriter.write(String.valueOf(result[i]));

            if (i != result.length - 1) {
                bufferedWriter.write("\n");
            }
        }

        bufferedWriter.newLine();

        bufferedWriter.close();

        scanner.close();
    }
}
