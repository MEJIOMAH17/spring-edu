package ru.sberbank.distributed.transaction.example.cdmstub;

import ru.sberbank.distributed.transaction.StepMetaInfo;
import ru.sberbank.distributed.transaction.example.steps.ExampleStep;

import java.util.Date;
import java.util.UUID;

public class Operation extends StepMetaInfo {
    private String id;
    private String type;
    private int stepId;
    private Object executionResult;


    Operation() {
        id = UUID.randomUUID().toString();
    }

    public String getId() {
        return id;
    }


    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }


    public Object getExecutionResult() {
        return executionResult;
    }

    public void setExecutionResult(Object executionResult) {
        this.executionResult = executionResult;
    }

    public int getStepId() {
        return stepId;
    }

    public void setStepId(int stepId) {
        this.stepId = stepId;
    }
}
