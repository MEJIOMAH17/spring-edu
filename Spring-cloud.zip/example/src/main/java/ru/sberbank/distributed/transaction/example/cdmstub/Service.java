package ru.sberbank.distributed.transaction.example.cdmstub;

import ru.sberbank.distributed.transaction.example.BaseScript;

import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class Service {
    private Map<String, Operation> operations = new HashMap<>();
    private Class<? extends BaseScript> scriptClass;
    private Status status;

    public Collection<Operation> operations() {
        return operations.values();
    }

    public Operation createOperaion(String type) {
        Operation operation = new Operation();
        operation.setType(type);
        operations.put(operation.getId(), operation);
        return operation;
    }

    public Operation getOperation(String id) {
        return operations.get(id);
    }

    public Class<? extends BaseScript> getScriptClass() {
        return scriptClass;
    }

    public void setScriptClass(Class<? extends BaseScript> scriptClass) {
        this.scriptClass = scriptClass;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public enum Status {
        ACTIVE,
        CANCELED,
        PERFORMED
    }
}
