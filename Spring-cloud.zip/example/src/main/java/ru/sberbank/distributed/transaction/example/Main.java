package ru.sberbank.distributed.transaction.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import ru.sberbank.distributed.transaction.core.DTBeanFactoryPostProcessor;
import ru.sberbank.distributed.transaction.core.DTBeanPostProcessor;
import ru.sberbank.distributed.transaction.example.cdmstub.CdmMock;
import ru.sberbank.distributed.transaction.example.cdmstub.Operation;
import ru.sberbank.distributed.transaction.example.cdmstub.Service;
import ru.sberbank.distributed.transaction.example.rollback.ContinueProcess;
import ru.sberbank.distributed.transaction.example.rollback.RollbackProcess;
import ru.sberbank.distributed.transaction.example.steps.AStep;
import ru.sberbank.distributed.transaction.example.steps.ExampleStep;

import java.util.Arrays;

@SpringBootApplication
public class Main {

    public static int min(int a, int b) {
        return a < b ? a : b;
    }
    public static int min(int a,int b ,int c,int d){
        int minAB = min(a, b);
        int minCD = min(c, d);
        return min(minAB, minCD);
    }

    public static void main(String[] args) {
        SpringApplication.run(Main.class, args);
    }

    /**
     * покажет время работы шагов
     *
     * @param ctx
     * @return
     */
    public Void test(ApplicationContext ctx) {
        Runnable action = () -> {
            ctx.getBean(AStep.class).regular(4);
        };
        for (int i = 0; i < 5; i++) {
            System.out.println("" + i + ": " + timeExec(action));
        }


        return null;
    }

    @Bean
    public Void scriptRun(Script script, ContinueProcess continueProcess, RollbackProcess rollbackProcess) {
        script.execute();
        System.out.println("**rollback_start**");
        rollbackProcess.rollback(script.getServiceId());
        return null;
    }

    @Bean
    public DTBeanPostProcessor dtBeanPostProcessor(CdmMock mock, DTBeanFactoryPostProcessor beanFactoryPostProcessor) {
        return new DTBeanPostProcessor(
                (step, params, executionNumber) -> {
                    System.out.println("save regular params:" + Arrays.toString(params));
                    ExampleStep exampleStep = (ExampleStep) step;
                    if (exampleStep.getServiceId() == null) {
                        return;
                    }
                    Service service = mock.getService(exampleStep.getServiceId());
                    Operation operation = service.createOperaion(exampleStep.getOperationType());
                    operation.setRollbackParams(params);
                    operation.setStepClass(exampleStep.getRealClassName());
                    operation.setStepId(exampleStep.getStepId());
                    operation.setExecutionNumber(executionNumber);
                    exampleStep.setOperationId(operation.getId());
                },
                (step, result, params) -> {
                    System.out.println("save rollback params:" + Arrays.toString(params));
                    System.out.println("save result params:" + result);
                    ExampleStep exampleStep = (ExampleStep) step;
                    Service service = mock.getService(exampleStep.getServiceId());
                    Operation operation = service.getOperation(exampleStep.getOperationId());
                    operation.setExecutionResult(result);
                    operation.setRollbackParams(params);
                },
                beanFactoryPostProcessor
        );
    }

    @Bean
    public DTBeanFactoryPostProcessor beanFactoryPostProcessor() {
        return new DTBeanFactoryPostProcessor();
    }

    private static long timeExec(Runnable runnable) {
        long start = System.nanoTime();
        runnable.run();
        return (System.nanoTime() - start) / 1000;
    }

}
