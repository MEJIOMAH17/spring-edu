package ru.sberbank.distributed.transaction.example.steps;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import ru.sberbank.distributed.transaction.annotation.FullRollback;
import ru.sberbank.distributed.transaction.annotation.ParticalRollback;
import ru.sberbank.distributed.transaction.annotation.Regular;
import ru.sberbank.distributed.transaction.annotation.Step;

@Step
public class CStep extends ExampleStep<CStep> {

    @Regular
    public String regular(long aResult,long bResult) {
        getRollbacker().rollback(aResult*bResult);
        return "hello from c";
    }

    @FullRollback
    public void rollback(long rollback) {
        System.out.println("Происходит откат " + rollback);
    }

    @ParticalRollback
    public void partical(long reg) {
        System.out.println("Частичный откат" + reg);
    }
}
