package ru.sberbank.distributed.transaction.example.steps;

import ru.sberbank.distributed.transaction.AbstractStep;

public class ExampleStep<T extends AbstractStep<T>> extends AbstractStep<T> {
    private String serviceId;
    private String operationType;
    private String operationId;

    public String getServiceId() {
        return serviceId;
    }

    public void setServiceId(String serviceId) {
        this.serviceId = serviceId;
    }

    public String getOperationType() {
        return operationType;
    }

    public void setOperationType(String operationId) {
        this.operationType = operationId;
    }

    public String getOperationId() {
        return operationId;
    }

    public void setOperationId(String operationId) {
        this.operationId = operationId;
    }
}

