package ru.sberbank.distributed.transaction.example.rollback;


import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;
import ru.sberbank.distributed.transaction.AbstractRollbackProcess;
import ru.sberbank.distributed.transaction.example.cdmstub.CdmMock;
import ru.sberbank.distributed.transaction.example.cdmstub.Operation;
import ru.sberbank.distributed.transaction.example.cdmstub.Service;

import java.util.Comparator;


@Component
public class RollbackProcess extends AbstractRollbackProcess {

    private CdmMock cdmMock;

    protected RollbackProcess(CdmMock cdmMock) {
        this.cdmMock = cdmMock;
    }

    public void rollback(String serviceId) {
        Service service = cdmMock.getService(serviceId);
        super.rollback(service.operations(), Comparator.comparing(Operation::getExecutionNumber));
    }

}
