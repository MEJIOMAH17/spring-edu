package ru.sberbank.distributed.transaction.example.cdmstub;

import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;
@Component
public class CdmMock {
    private Map<String,Service> serviceMap=new HashMap<>();
    public Service getService(String id){
        Service service = serviceMap.get(id);
        if(service==null){
           service= createService(id);
           serviceMap.put(id,service);
        }
        return service;
    }
    public Service createService(String id){
        Service service = new Service();
        return service;
    }

}
