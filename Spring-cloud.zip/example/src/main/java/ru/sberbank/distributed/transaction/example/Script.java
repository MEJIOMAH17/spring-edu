package ru.sberbank.distributed.transaction.example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import ru.sberbank.distributed.transaction.example.rollback.ContinueProcess;
import ru.sberbank.distributed.transaction.example.rollback.RollbackProcess;
import ru.sberbank.distributed.transaction.example.steps.AStep;
import ru.sberbank.distributed.transaction.example.steps.BStep;
import ru.sberbank.distributed.transaction.example.steps.CStep;
import ru.sberbank.distributed.transaction.example.steps.ExampleStep;

import javax.annotation.PostConstruct;
import java.util.Calendar;


@Component
@Scope("prototype")
public class Script extends BaseScript {
    //<editor-fold desc="Interior">
    private final RollbackProcess rollbackExample;
    private final ContinueProcess continueExample;

    @Autowired
    public Script(ContinueProcess continueExample,
                  RollbackProcess rollbackExample) {
        this.continueExample = continueExample;
        this.rollbackExample = rollbackExample;
    }

    @Override
    protected Integer errorRs(Exception e) {
        return null;
    }
    //</editor-fold>


    public Integer innerRun() {
        createService("serviceId");
        AStep astep = getStep(AStep.class, "astep");
        BStep bStep = getStep(BStep.class, "bstep");
        CStep cStep = getStep(CStep.class, "cStep");
        Calendar aResult = astep.regular(7);
        String bResult = bStep.regular(aResult.getTimeInMillis());
        cStep.regular(aResult.getTimeInMillis(), bResult.length());
        registerResponse();
        return 4;
    }


    //<editor-fold desc="Footer">
    private <T extends ExampleStep> T getStep(Class<T> stepClass, String operationType) {
        T step = (T) super.getStep(stepClass);
        step.setServiceId(getServiceId());
        step.setOperationType(operationType);
        return step;
    }

    private <T extends ExampleStep> void patchStep(T step, String type) {
        step.setServiceId(getServiceId());
        step.setOperationType(type);
        return;
    }
    //</editor-fold>
}
