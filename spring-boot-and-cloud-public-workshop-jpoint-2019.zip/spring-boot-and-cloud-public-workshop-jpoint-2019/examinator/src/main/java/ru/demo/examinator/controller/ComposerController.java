package ru.demo.examinator.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import ru.demo.Exam;
import ru.demo.Exercise;
import ru.demo.Section;

import javax.annotation.PostConstruct;
import java.net.URI;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequiredArgsConstructor
public class ComposerController {
    private final RestTemplate restTemplate;
    @Autowired
    private DiscoveryClient discoveryClient;

    private Map<String, String> seviceUrlByName = new HashMap<>();


    @PostConstruct
    public void init() {
        seviceUrlByName.put("math", "http://localhost:8081/random");
        seviceUrlByName.put("java", "http://localhost:8082/random");
    }

    @PostMapping("/exam")
    public Exam getExam(@RequestBody Map<String, Integer> sections) {
        discoveryClient.getInstances("math").get(0).getUri();
        return Exam.builder()
                .sections(sections.entrySet().stream()
                        .map(entry -> {
                            String sectionName = entry.getKey();
                            int amount = entry.getValue();
                            URI serviceUrl = discoveryClient.getInstances(sectionName).get(0).getUri();
                            Exercise[] forObject = restTemplate.getForObject(
                                    serviceUrl + "random/?amount=" + amount,
                                    Exercise[].class
                            );

                            return Section.builder()
                                    .exercises(Arrays.asList(forObject))
                                    .build();
                        })
                        .collect(Collectors.toList()))
                .build();
    }
}
